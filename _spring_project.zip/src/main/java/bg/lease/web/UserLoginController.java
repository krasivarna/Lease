package bg.lease.web;

import bg.lease.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserLoginController {

    private UserService userService;

    public UserLoginController(UserService userService){
        this.userService=userService;
    }

    @GetMapping("/users/login")
    public String login(){

        return "login";
    }

}
