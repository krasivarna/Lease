package bg.lease.web;

import bg.lease.model.dto.LeaseCardDTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class testController {

    @ModelAttribute
    public void initForm(Model model){
        model.addAttribute("test",new LeaseCardDTO());
    }


    @GetMapping("/test")
    public String doTest(){
        return "test";
    }
}
