package bg.lease.model.dto;

public class VendorSmallDTO {
    private String no;
    private String name;
    private String vatRegistration;

    public VendorSmallDTO(){}

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVatRegistration() {
        return vatRegistration;
    }

    public void setVatRegistration(String vatRegistration) {
        this.vatRegistration = vatRegistration;
    }
}
