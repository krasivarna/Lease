package bg.lease.model.dto;

public class CountryDTO {
    private String no;
    private String name;

    public CountryDTO() {
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
