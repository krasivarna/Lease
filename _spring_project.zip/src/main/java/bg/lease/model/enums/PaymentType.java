package bg.lease.model.enums;

public enum PaymentType {
    EqPrincipal,EqPayment;
}
