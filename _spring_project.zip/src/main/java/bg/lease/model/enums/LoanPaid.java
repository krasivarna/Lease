package bg.lease.model.enums;

public enum LoanPaid {
    PaidEnd,PaidBegin,PaidBegin_1;
}
