package bg.lease.model.enums;

public enum LoanType {
    Finance,Operative;
}
