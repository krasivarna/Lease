package bg.lease.model.enums;

public enum LeaseStatus {
    Empty,FillBegin,Active,Closed,Reoffer,Cancel,Early;
}
