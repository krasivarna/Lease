package bg.lease.model.enums;

public enum InvoiceType {
    InBegin,EveryMonth;
}
