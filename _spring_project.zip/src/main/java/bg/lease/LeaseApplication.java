package bg.lease;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(LeaseApplication.class, args);
    }

}
