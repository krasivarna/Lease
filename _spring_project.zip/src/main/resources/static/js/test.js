function ClickTest(event) {
    let $grid=document.getElementById('lookup-vendor');
    let $contract=document.getElementById('contractNo');
    $grid.style.zIndex='5';
    $grid.style.width='400px';
    $grid.style.height='300px';
    $grid.style.left=event.clientX+'px'; //'330px'; //$contract.clientLeft+'px';
    $grid.style.top=event.clientY+'px'; //'230px';  //$contract.clientTop+'px';
    $grid.classList.toggle('show');
    document.getElementById('title').textContent='position:'+
        event.clientX +
        ','+
        event.clientY;
}

function CreateLookup(keySearch) {
    let main=document.getElementById('main');
    let basicDiv=document.createElement('div');

    main.appendChild(basicDiv);

    basicDiv.setAttribute('id','lookup-vendor');
    basicDiv.classList.add('dropdown-content');
    let form=document.createElement('form');

    basicDiv.appendChild(form);

    form.classList.add('order');
    form.classList.add('fixedTable');
    form.method='post';

    let table=document.createElement('table');
    table.setAttribute('role','grid');

    form.appendChild(table);

    let thead=document.createElement('thead');
    table.appendChild(thead);

    let rowHead=document.createElement('tr');
    let VendorNoCaption=document.createElement('th');
    VendorNoCaption.textContent='Vendor no.';
    let VendorNameCaption=document.createElement('th');
    VendorNameCaption.textContent='Vendor name';
    let VendorVatNoCaption=document.createElement('th');
    VendorVatNoCaption.textContent='VAT No.';
    rowHead.appendChild(VendorNoCaption);
    rowHead.appendChild(VendorNameCaption);
    rowHead.appendChild(VendorVatNoCaption)

    thead.appendChild(rowHead);

    let tbody=document.createElement('tbody');
    tbody.setAttribute('role','rowgroup');
    table.appendChild(tbody);

    var requestOptions={method:'GET',redirect:'follow'};

    let restLink='';
    if (keySearch===""){
        restLink='http://localhost:8080/vendorsmalllist';
    } else {
        restLink ='http://localhost:8080/vendorsmalllist?key='+keySearch;
    }
    fetch(restLink,requestOptions)
        .then(response=>response.json())
        .then(json=>json.forEach(vendor => {

            let row = document.createElement('tr');
            row.setAttribute('role', 'row');
            let VendorNo = document.createElement('td');
            VendorNo.setAttribute('role', 'gridcell');
            let a = document.createElement('a');
            a.href = '/vendorcard/' + vendor.no;
            a.textContent = vendor.no;

            VendorNo.appendChild(a);
            row.appendChild(VendorNo);

            let VendorName = document.createElement('td');
            VendorName.setAttribute('role', 'gridcell');
            let span = document.createElement('span');
            span.textContent = vendor.name;

            VendorName.appendChild(span);
            row.appendChild(VendorName);
            tbody.appendChild(row);
        }));


    ClickTest(event);
}