package bg.lease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
